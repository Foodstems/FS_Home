// create the back to top button
//jQuery('body').prepend('<a href="javascript:void(0)" class="fs-back-to-top"> <i class="fa fa-angle-top"></i></a>');
var hostname = window.location.host;
var api_host = Foodstems.api_host;
var app_host = Foodstems.app_host;

var ajaxInProgress = false;


$( document ).ajaxStart(function() {
   ajaxInProgress = true;
   $("#products-done-button").addClass("disabled");
   $(".products-save-btn").addClass("disabled");
});

$( document ).ajaxStop(function() {
   ajaxInProgress = false;
   $("#products-done-button").removeClass("disabled");
   $(".products-save-btn").removeClass("disabled");
});


var amountScrolled = 300;
jQuery(document).ready(function(){
	jQuery(window).scroll(function() {
		if ( jQuery(window).scrollTop() > amountScrolled ) {
			jQuery('a.fs-back-to-top').fadeIn('slow');
		} else {
			jQuery('a.fs-back-to-top').fadeOut('slow');
		}
	});
	jQuery('a.fs-back-to-top').click(function() {
		jQuery('html, body').animate({
			scrollTop: 0
		}, 2000);
		return false;
	});

   $.get(Foodstems.api_host+'/api/categories', function(data){

		$.each(data.data, function(key, value) {

		     $('#category_id')
		         .append($("<option></option>")
		                    .attr("value",value.id)
		                    .text(value.name)); 

		    // set vegetables selected
		    $("#category_id").val("4");
		});   		
	});	
});

//https://stackoverflow.com/questions/2855865/validating-email-addresses-using-jquery-and-regex
function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};

$(document).on("keyup change blur", ".register-email", function(e) {
	//return true;
	var email = $.trim($(this).val());
	console.log(email);
	if (isValidEmailAddress(email)) {
		$.ajax({
			url : api_host + "/api/users/onboard/check_email",
			type : "POST",
			data : "email=" + email,
			success: function(res) {
				var exist = res.data;
				if (parseInt(exist) == 0) {
					$(".invalid-email").hide()
					$("#continue_sign_up").val(1)
				} else {
					$(".invalid-email").html("Email is already taken").show()
					$("#continue_sign_up").val(0)
				}
			
			},
			error: function(res) {
				console.log(res)
				//console.log(res)
				//$("#email").append('<span class="help-inline">Something may have gone wrong</span>')
				$(".invalid-email").html("Email is already taken").show()
				$("#continue_sign_up").val(0)
			}
		})
	}
})
	
function signupSeller() {

	if (!$("#firstname").val() || !$("#lastname").val() || !$("#companyname").val()) {
		return false;
	}
	if ($("#continue_sign_up").val() == "0" ) {
		return false;
	}
	
	if(!$('#email').val())
		return false;
	
	var seller_data = {};
	seller_data.firstname = $("#firstname").val();
	seller_data.lastname = $("#lastname").val();
	seller_data.companyname = $("#companyname").val();
	window.location = '/onboard/seller/register?email='+$('#email').val()+'&firstname='+$('#firstname').val()+'&lastname='+$('#lastname').val()+'&companyname='+$('#companyname').val();

	// store email address
	
	$.ajax({
		type : "POST",
		url : api_host + "/api/users/onboard/save_address",
		data : {"type":"seller","email" : $("#email").val(), "data" : JSON.stringify(seller_data)},
		success :function(res){
			//$('#sign-up-top').hide();
			//$('#sign-up-top-hidden').show();
			window.location = '/onboard/seller/register?email='+$('#email').val()+'&firstname='+$('#firstname').val()+'&lastname='+$('#lastname').val()+'&companyname='+$('#companyname').val();

		}
	})
	/*
	seller_data.email=$("#email").val();
	seller_data.signup_type='seller';
	$.ajax({
		type : "POST",
		url  : "https://dev.foodstems.com/v2/api/email/signup_to_list",
		data : seller_data
	})
	*/
	//window.location = '/onboarding-seller?email='+$('#email').val()+'&firstname='+$('#firstname').val()+'&lastname='+$('#lastname').val()+'&companyname='+$('#companyname').val();
	
}	

/* scroll top bottom arrow */
jQuery(document).ready(function(){
	jQuery('a.sign-up-top').on('click',function (e) {
		jQuery('html, body').stop().animate({
			'scrollTop': jQuery($(this).attr('rel')).offset().top - 30
		}, 2000, 'swing', function () {});
	});
});



jQuery(document).ready(function () { 



	jQuery('.btn-first-back').on( "click", function() {
		jQuery('#fs_first_step').addClass('show-data');
        jQuery('#fs_first_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        
    });
	
	
	
	jQuery('.btn-second-back').on( "click", function() {
		jQuery('#fs_second_step').addClass('show-data');
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_third_step').addClass('hide-data');
        jQuery('#fs_third_step').removeClass('show-data');
		
        
    });	


});	
function register_seller() {
	//var user_params = get_user_object();
	var data = $("#the-user").val();
	var user_params = JSON.parse(data);
	$("#register_seller_btn").hide();
	$("#register-seller-row").hide();
	$("#loading-button-seller").show();
	//console.log(user_params); return false;
	$.ajax({
	    url: api_host + "/api/users/onboard",
	    type: "POST", /* or type:"GET" or type:"PUT" */
	    timeout: 0,
	    data: 	user_params,
	    success: function (result) {
	        window.localStorage.setItem('user', JSON.stringify({"user":result.data[0]}));
	        var hash = btoa(JSON.stringify({"user":result.data[0]}));
	        window.location.href = app_host + "/login?redirecty=inventory&hash=" + hash;
	        
	    }, 
	    error: function(result) {
	    	$("#succes-div").hide();
	        $("#error-div").show();
	        $("#loading-button-buyer").hide();
	    }
	});
}

function validate_first_step() {
	var ret = true;
	var company_name = $('#company-name');
	var company_description = $('#company-description');
	var farm_location = $('#farm-location');
	var first_name 	= $("#firstname");
	var last_name 	= $("#lastname");
	company_name.removeClass('invalid');
	company_description.removeClass('invalid');
	$('.btn-img').removeClass('invalid');
	farm_location.removeClass('invalid');
	
	if(!company_name.val()) {
		company_name.addClass('invalid');
		ret = false;
	}
	if(!company_description.val()) {
		company_description.addClass('invalid');
		ret = false;
	}
	if(!avatar_added) {
		$('.btn-img').addClass('invalid');
		ret = false;
	}
	if(!location_added) {
		farm_location.addClass('invalid');
		ret = false;
	}
	
	if(ret) {
		user.company_name = company_name.val();
		user.company_description = company_description.val();
		user.first_name = first_name.val();
		user.last_name = last_name.val();
	}
	save_user_object();
	return ret;
}

function validate_second_step() {
	
	$('#user-locations').removeClass('invalid');

	if($('#my-locations-added').val()=="0") {
		$('#user-locations').addClass('invalid');
		return false;
	}
	user.user_locations = {}
	$(".selected_market_times").each(function(k, v) {
		user.user_locations[$(v).val()] = $(v).val()
	})
	
	save_user_object();

	return true;
}

function validate_third_step() {
	if($('#saved-products').html()=='') {
		alert('Please add at least one product');
		return false;
	}
	save_user_object();
	return true;
}

var user;

var avatar_added = false;
var location_added = false;
var product_tags_suggest = null;


function getOrientation(file, callback) {
  var reader = new FileReader();
  
  reader.onload = function(event) {
    var view = new DataView(event.target.result);
 	
    if (view.getUint16(0, false) != 0xFFD8) return callback(-2);
 
    var length = view.byteLength,
        offset = 2;
 
    while (offset < length) {
      var marker = view.getUint16(offset, false);
      offset += 2;
 
      if (marker == 0xFFE1) {
        if (view.getUint32(offset += 2, false) != 0x45786966) {
          return callback(-1);
        }
        var little = view.getUint16(offset += 6, false) == 0x4949;
        offset += view.getUint32(offset + 4, little);
        var tags = view.getUint16(offset, little);
        offset += 2;
 
        for (var i = 0; i < tags; i++)
          if (view.getUint16(offset + (i * 12), little) == 0x0112)
            return callback(view.getUint16(offset + (i * 12) + 8, little));
      }
      else if ((marker & 0xFF00) != 0xFF00) break;
      else offset += view.getUint16(offset, false);
    }
    return callback(-1);
  };
 
  reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
};

$(function(){
	
	$('#upload-profile-image').change(function(){
		var file = $(this)[0].files[0];

		var reader = new FileReader();

		var size = document.getElementById('upload-profile-image').files[0].size;
		srcOrientation = 6
		getOrientation(file, function(orientation) {
		    srcOrientation = orientation;
		});
		$("#upload-profile-image-spinner").show();
		reader.onload = function(e) {
			var img = document.createElement("img");
        	img.src = reader.result;
        	
        	
        	img.onload = function() {

				var canvas = document.createElement("canvas");
		        var ctx = canvas.getContext("2d");
		        ctx.drawImage(img, 0, 0);
		 
		        var MAX_WIDTH   = 400;
		        var MAX_HEIGHT  = 400;
		        var width       = img.width;
		        var height      = img.height;
		 
		        var tmp_ratio_width = width/MAX_WIDTH;
		        var tmp_ratio_height = height/MAX_HEIGHT;
		 
		        var tmp_ratio = tmp_ratio_width;
		        if(tmp_ratio_width<tmp_ratio_height)
		            tmp_ratio = tmp_ratio_height;
		           
		        if(tmp_ratio>1) {
		            width=width/tmp_ratio;
		            height=height/tmp_ratio;
		        }
		 
		        canvas.width = width;
		        canvas.height = height;
		        var ctx = canvas.getContext("2d");
		        switch (srcOrientation) {
		          case 2: ctx.transform(-1, 0, 0, 1, width, 0); break;
		          case 3: ctx.transform(-1, 0, 0, -1, width, height ); break;
		          case 4: ctx.transform(1, 0, 0, -1, 0, height ); break;
		          case 5: ctx.transform(0, 1, 1, 0, 0, 0); break;
		          case 6:
		          canvas.width=height;
		          canvas.height=width;
		          ctx = canvas.getContext("2d");
		          ctx.transform(0, 1, -1, 0, height, 0);
		          break;
		          case 7: ctx.transform(0, -1, -1, 0, height , width); break;
		          case 8: ctx.transform(0, -1, 1, 0, 0, width); break;
		          default: ctx.transform(1, 0, 0, 1, 0, 0);
		        }

		    	ctx.drawImage(img, 0, 0, width, height);

		    	var dataurl = canvas.toDataURL("image/png");	
		    	upload_image(dataurl, $("#email").val(), "uploaded-avatar");
        		jQuery.each($('.form-img-1 img'), function(i, e){
		        	user.avatar = dataurl;
					avatar_added = true;
					save_user_object();		
					e.src = dataurl;
			
					$('#uploaded-avatar').attr('src', dataurl);

				});
        	}

        }
		if (file) {
			reader.readAsDataURL(file);
		}
	});
	
	jQuery('.btn-second-next').on( "click", function() {
		if(!validate_first_step())
			return false;

		update_profile_image();

        jQuery('#fs_first_step').removeClass('show-data');
		jQuery('#fs_first_step').addClass('hide-data');        
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('show-data');
    });
	
	jQuery('.btn-third-next').on( "click", function() {
		if(!validate_second_step())
			return false;

		update_profile_image();

        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        jQuery('#fs_third_step').removeClass('hide-data');
        jQuery('#fs_third_step').addClass('show-data');
    });
	
	jQuery('.btn-form-done').on( "click", function() {
		if(!validate_third_step())
			return false;

		update_profile_image();

		if($('#product-name').val()!="" || $('#product-description').val()!=""
			|| $('#product-image-1').attr('src')!='/assets/onboard/images/upload-icon.png'
			|| $('#product-image-2').attr('src')!='/assets/onboard/images/upload-icon.png'
			|| $('#product-image-3').attr('src')!='/assets/onboard/images/upload-icon.png'
			|| product_tags_suggest.getValue().length!=0) {
			if(!confirm('Are you sure you want to continue without adding your next product?'))
				return false;
		}

		jQuery('#fs_third_step').addClass('hide-data');
        jQuery('#fs_third_step').removeClass('show-data');
        jQuery('#fs_fourth_step').removeClass('hide-data');
        jQuery('#fs_fourth_step').addClass('show-data');
        user.email = jQuery("#email").val();
		$('#the-user').html(JSON.stringify(user));
		$('#the-user').val(JSON.stringify(user));
        //console.log(user);
    });

	
	$('#add-user-location').click(function() {
		var id = new Date().getTime();
		//var place = autocomplete2.getPlace();
		if(typeof place == 'undefined')
			return false;
		$('#my-locations').append('<div class="col-md-12" style="background-color:#eee;" id="user-address-'+id+'"><div class="col-md-5">Location</div><div class="col-md-7 address-name" style="border: 1px dotted grey;">'+place.formatted_address+'</div><div class="col-md-5">Hours</div><div class="col-md-7">    <select class="select-day"><option>Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option></select>:    <select class="select-from"><option>00 AM</option><option>01 AM</option><option>02 AM</option><option>03 AM</option><option>04 AM</option><option>05 AM</option><option>06 AM</option><option>07 AM</option><option>08 AM</option><option>09 AM</option><option>10 AM</option><option>11 AM</option><option>12 PM</option><option>01 PM</option><option>02 PM</option><option>03 PM</option><option>04 PM</option><option>05 PM</option><option>06 PM</option><option>07 PM</option><option>08 PM</option><option>09 PM</option><option>10 PM</option><option>11 PM</option></select>-<select class="select-to"><option>00 AM</option><option>01 AM</option><option>02 AM</option><option>03 AM</option><option>04 AM</option><option>05 AM</option><option>06 AM</option><option>07 AM</option><option>08 AM</option><option>09 AM</option><option>10 AM</option><option>11 AM</option><option>12 PM</option><option>01 PM</option><option>02 PM</option><option>03 PM</option><option>04 PM</option><option>05 PM</option><option>06 PM</option><option>07 PM</option><option>08 PM</option><option>09 PM</option><option>10 PM</option><option>11 PM</option></select></div><a href="#" onclick="addTimesToLocation()" id="add_times">+</a><div class="col-md-4 col-md-offset-4"><a href="#" class="btn btn-success pull-left" onclick="saveLocation('+id+')">Save</a><a href="#" class="btn btn-default pull-right" onclick="removeAddress('+id+')">Remove</a></div></div>');
	});
	
	$('.product-image-upload').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		var id = $(this).data('id');
		$("#product-image-spinner-" + id).show();
		reader.addEventListener("load", function () {

                var img = document.createElement("img");
                img.src = reader.result;
                img.onload = function() {

                    var canvas = document.createElement("canvas");
                    var ctx = canvas.getContext("2d");
                    ctx.drawImage(img, 0, 0);

                    var MAX_WIDTH   = 500;
                    var MAX_HEIGHT  = 500;
                    var width       = img.width;
                    var height      = img.height;

                    var tmp_ratio_width = width/MAX_WIDTH;
                    var tmp_ratio_height = height/MAX_HEIGHT;

                    var tmp_ratio = tmp_ratio_width;
                    if(tmp_ratio_width<tmp_ratio_height)
                        tmp_ratio = tmp_ratio_height;

                    if(tmp_ratio>1) {
                        width=width/tmp_ratio;
                        height=height/tmp_ratio;
                    }

                    canvas.width = width;
                    canvas.height = height;
                    var ctx = canvas.getContext("2d");

                    ctx.drawImage(img, 0, 0, width, height);

                    var dataurl = canvas.toDataURL("image/png");

                    upload_product_image(dataurl, $("#email").val(), id);

					$('#product-image-'+id).attr('src', dataurl);


			}


		}, false);

		if (file) {
			reader.readAsDataURL(file);
		}
	});


	
	load_user();
});

function update_profile_image() {
	jQuery.each($('.form-img-1 img'), function(i, e){
		e.src = user.avatar;
	});
}

function removeAddress(id) {
	$('#user-address-'+id).remove();
}

function saveLocation(id) {
	$('#my-saved-locations').append('<div class="col-md-12" style="background-color:#eee;">'+$('#user-address-'+id+' .address-name').html()+' '+$('#user-address-'+id+' .select-day option:selected').html()+' '+$('#user-address-'+id+' .select-from option:selected').html()+' '+$('#user-address-'+id+' .select-to option:selected').html()+'</div>');
	$('#user-address-'+id).remove();
}

function removeProduct() {
	clearProductForm();
}

function clearProductForm() {
	$('#product-name').val('');
	$('#product-description').val('');
	$('#product-image-1').attr('src', '/assets/onboard/images/upload-icon.png');
	$('#product-image-2').attr('src', '/assets/onboard/images/upload-icon.png');
	$('#product-image-3').attr('src', '/assets/onboard/images/upload-icon.png');
}

function saveProduct() {
	$('#product-name').removeClass('invalid');
	$('#product-description').removeClass('invalid');
	$('#product-image-1').removeClass('invalid');
	
	var product = {};
	product.name = $('#product-name').val();
	product.description = $('#product-description').val();
	product.category_id = $("#category_id").val();
	product.images = [];
	if($('#product-image-1').attr('src')!='/assets/onboard/images/upload-icon.png')
		product.images.push($('#product-image-1').attr('src'));
	if($('#product-image-2').attr('src')!='/assets/onboard/images/upload-icon.png')
		product.images.push($('#product-image-2').attr('src'));
	if($('#product-image-3').attr('src')!='/assets/onboard/images/upload-icon.png')
		product.images.push($('#product-image-3').attr('src'));
	product.tags = product_tags_suggest.getValue();
	// empty tags for the next product
	$('#product-tags').magicSuggest().clear()
	
	if(!product.name)
		$('#product-name').addClass('invalid');
	if(!product.description)
		$('#product-description').addClass('invalid');
	if(typeof product.images[0] == 'undefined')
		$('#product-image-1').addClass('invalid');
	
	if(product.name && product.description && typeof product.images[0] !='undefined') {
		$('#saved-products').append('<span class="product-text"><span class="product-img"><img class="img-responsive" src="'+product.images[0]+'"/></span><h3>'+product.name+'</h3><span class="close" onclick="removeThisProduct('+user.products.length+', this)">X</span></span>');
		clearProductForm();

		user.products.push(product);

		$('#products-done-button').removeClass('disabled');
	}
}

function removeThisProduct(index, el) {
	user.products.splice(index, 1);

	$(el).parent().remove();

	if(user.products.length==0)
		$('#products-done-button').addClass('disabled');
}

function get_market() {
	$("#my-locations").empty()
	$('#my-locations-container').show();
	var selected_market_id = $("#market_id").val()
	var market_data = $("#market_" + selected_market_id + "_data").html()
	$("#my-locations").append(market_data);
	if (selected_market_id) {
		//user.user_locations[selected_market_id] = selected_market_id
		$("#my-locations-added").val("1")
	}
}

$(document).on("click", ".remove-market", function(e) {
	$(this).closest("table").remove();
})

function edit_market(id)
{	

	
	var selected_markets = []
 	$('#market_id')
         .append($("<option selected='selected'></option>")
                    .attr("value",id)
                    .text(markets[id])); 

	// get selected markets
	$("#market_info_" + id).find(".selected_market_times").each(function(k, v) {
		selected_markets.push($(v).val())
	})

	$("#my-saved-locations").find("#market_info_" + id).remove();
	$("#my-locations").empty()
	$('#my-locations-container').show();
	var selected_market_id = id;
	var market_data = $("#market_" + selected_market_id + "_data").html()
	$("#my-locations").append(market_data);

	if (selected_market_id) {
		$("#my-locations-added").val("1")
	}	

	// set checked previosly selected options
	console.log(selected_markets)
	$("#my-locations").find(".market_time").each(function(k, v) {
		var market_time = $(v).val()
		if (selected_markets.indexOf(market_time) != -1) {
			$(v).prop("checked", true)
		}
	})


}

function add_market(id=false) {
	var market_name = ""
	var market_times = {}
	var table = $(this).closest("table")
	if (!id) {
	var market_id = $("#market_id").val();
	} else {
		var market_id = id;
	}
	// remove if existing with this id
	$("#market_info_"+market_id).remove();
	if($(".market_time:checked").length < 1)
		return false;
	$(".market_time:checked").each(function(k, v) {
		var _table = $(this).closest("table")
		market_name = $(_table).find(".market_name_td").text()
		var txt 	= $("#label_m_time_" + $(v).val()).text()
		market_times[$(v).val()] = txt;
	})
	$("#market_info_" + market_id).remove()
	var _html = ""
	_html += "<span id='market_info_"+market_id+"' class='location-text col-md-12'>"
	_html += market_name;
	$.each(market_times, function(k, v) {
			_html += "<input type='hidden' name='selected_market_times' class='selected_market_times' value='"+k+"' />"
	})
	_html +="<a href='' class='pull-right edit-location-link' onclick='edit_market("+market_id+"); return false;'><i class='fa fa-pencil'></i></a>"
	_html += "</span>"
	$("#my-saved-locations").append(_html)
	$('#my-locations-container').hide();

	$("#my-locations").find('table').remove()

	$("#market_id option[value='"+market_id+"']").remove();
	//console.log(user.user_locations)
}

function add_email(email) {
	user.email = email
}
function init_user() {
	return {
		email: "",
		avatar: "",
		first_name: "",
		last_name: "",
		company_name: "",
		company_description: "",
		farm_location: {},
		user_locations: {},
		products: [], 
		type: "seller"
	};
}

function clear_user_object() {
	window.localStorage.removeItem("user_seller");
}
function save_user_object() {
	var user2 = Object.assign({}, user);
	user2.products = [];
	window.localStorage.setItem('user_seller_' + $("#email").val(), JSON.stringify(user2));
}

function get_user_object() {
	return JSON.parse(window.localStorage.getItem('user_seller_' + $("#email").val()));	
}

function load_user() {
	user = get_user_object();

	if(user == null)
		user = init_user();
	
	if(user.avatar!="") {
		jQuery.each($('#uploaded-avatar'), function(i, e){
				e.src = user.avatar;
			});
		avatar_added = true;
	}
	
	if(user.company_name!="") {
		$('#company-name').val(user.company_name);
	}
	
	if(user.company_description!="") {
		$('#company-description').val(user.company_description);
	}

	if(user.farm_location!={}) {
		$('#farm-location').val(user.farm_location.formatted_address);
		location_added = true;
	}
}


function upload_image(data, email, id)
{	
	$.ajax({
		type: "POST",
		url: api_host + "/api/onboard/upload_image",
		data:{image:data, email:email},
	})
	.done(function(response){
		$("#"+id).attr("src", response.image);
		user.avatar = response.image;
		avatar_added = true;
		save_user_object();		
		$("#upload-profile-image-spinner").hide();
	})
	.fail(function(error){
		console.log(error)
	});
}

function upload_product_image(data, email, id)
{	
	$.ajax({
		type: "POST",
		url: api_host + "/api/onboard/upload_image",
		data:{image:data, email:email},
	})
	.done(function(response){
		$('#product-image-'+id).attr('src', response.image);
		$("#product-image-spinner-" + id).hide();
	})
	.fail(function(error){
		console.log(error)
	});
}