// create the back to top button
//jQuery('body').prepend('<a href="javascript:void(0)" class="fs-back-to-top"> <i class="fa fa-angle-top"></i></a>');
var hostname = window.location.host;
var api_host = Foodstems.api_host;
var app_host = Foodstems.app_host;


var ajaxInProgress = false;


$( document ).ajaxStart(function() {
   ajaxInProgress = true;
   $("#register_btn").hide();
});

$( document ).ajaxStop(function() {
   ajaxInProgress = false;
   $("#register_btn").show();
});


var amountScrolled = 300;
jQuery(document).ready(function(){
	jQuery(window).scroll(function() {
		if ( jQuery(window).scrollTop() > amountScrolled ) {
			jQuery('a.fs-back-to-top').fadeIn('slow');
		} else {
			jQuery('a.fs-back-to-top').fadeOut('slow');
		}
	});
	jQuery('a.fs-back-to-top').click(function() {
		jQuery('html, body').animate({
			scrollTop: 0
		}, 2000);
		return false;
	});
});

//https://stackoverflow.com/questions/2855865/validating-email-addresses-using-jquery-and-regex
function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};

$(document).on("keyup change blur", ".register-email", function(e) {
	var email = $.trim($(this).val())
	if (isValidEmailAddress(email)) {
		$.ajax({
			url : api_host + "/api/users/onboard/check_email",
			type : "POST",
			data : "email=" + email,
			success: function(res) {
				var exist = res.data;
				if (parseInt(exist) == 0) {
					$(".invalid-email").hide()
					$("#continue_sign_up").val(1)
				} else {
					$(".invalid-email").html("Email is already taken").show()
					$("#continue_sign_up").val(0)
				}
			},
			error: function(res) {
				//console.log(res)
				//$("#email").append('<span class="help-inline">Something may have gone wrong</span>')
				$(".invalid-email").html("Email is already taken").show()
				$("#continue_sign_up").val(0)
			}
		})
	}
})

function onboardBuyer1() {

	if ($("#continue_sign_up").val() == "0" ) {
		return false;
	} 

	if(!$('#email1').val())
		return false;

	window.location='/onboard/buyer/register?email='+$('#email1').val();

	$.ajax({
		type : "POST",
		url : api_host + "/api/users/onboard/save_address",
		data : {"email" : $("#email1").val(), 'type' : 'buyer'},
		success :function(res){
			//$('.sign-up-wrapper').hide();
			//$('.sign-up-top-hidden').show();
			window.location='/onboard/buyer/register?email='+$('#email1').val();
		}
	})
	/*	
	$.ajax({
		type : "POST",
		url  : "https://dev.foodstems.com/v2/api/email/signup_to_list",
		data : {
			email: $('#email1').val()
		}
	})
	*/
}

function register_buyer() {
	//var user_params = get_user_object();
	var data = $("#the-user").val();
	var user_params = JSON.parse(data);
	user_params.email = $("#email").val();
	$("#register_btn").hide();
	$("#register-buyer-row").hide();
	$("#loading-button-buyer").show();
	//console.log(user_params); return false;
	$.ajax({
	    url: api_host + "/api/users/onboard",
	    type: "POST", /* or type:"GET" or type:"PUT" */
	    timeout: 0,
	    data: 	user_params,
	    success: function (result) {
	        var hash = btoa(JSON.stringify({"user":result.data[0]}));
	        window.location.href = app_host + "/login?redirecty=browse&hash=" + hash;
	    },
	    error: function (response) {
	    	$("#succes-div").hide();
	        $("#error-div").show();
	        $("#loading-button-buyer").hide();
	    }
	});
}

function onboardBuyer2() {
	
	if ($("#continue_sign_up").val() == "0" ) {
		return false;
	} 

	if(!$('#email2').val())
		return false;

	//window.location='/onboarding-buyer?email='+$('#email2').val();
	// store email address
	$.ajax({
		type : "POST",
		url : api_host + "/api/users/onboard/save_address",
		data : {"email" : $("#email2").val(), 'type' : 'buyer'},
		success :function(res){
			//$('.sign-up-wrapper').hide();
			//$('.sign-up-top-hidden').show();
			window.location='/onboard/buyer/register?email='+$('#email2').val();
		}
	})

		$.ajax({
		type : "POST",
		//url  : "https://dev.foodstems.com/v2/api/email/signup_to_list",
		url  : Foodstems.api_host + "api/email/signup_to_list",
		data : {
			email: $('#email2').val()
		}
	})

}

/* scroll top bottom arrow */
jQuery(document).ready(function(){
	jQuery('a.sign-up-top').on('click',function (e) {
		jQuery('html, body').stop().animate({
			'scrollTop': 100
		}, 2000, 'swing', function () {});
	});
});



jQuery(document).ready(function () { 
	jQuery('.btn-first-back').on( "click", function() {
		jQuery('#fs_first_step').addClass('show-data');
        jQuery('#fs_first_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        
    });
	
	
	
	jQuery('.btn-second-back').on( "click", function() {
		jQuery('#fs_second_step').addClass('show-data');
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_third_step').addClass('hide-data');
        jQuery('#fs_third_step').removeClass('show-data');
		
        
    });	
});	

function validate_first_step() {
	var ret = true;
	var company_name = $('#company-name');
	var user_location = $('#user-location');
	
	company_name.removeClass('invalid');
	$('.btn-img').removeClass('invalid');
	user_location.removeClass('invalid');
	
	if(!company_name.val()) {
		company_name.addClass('invalid');
		ret = false;
	}
	if(!avatar_added) {
		$('.btn-img').addClass('invalid');
		ret = false;
	}
	if(!location_added) {
		user_location.addClass('invalid');
		ret = false;
	}
	
	if(ret) {
		user.company_name = company_name.val();
	}
	save_user_object();

	return ret;
}

function validate_second_step() {
	$('#user-tags').removeClass('invalid');
	if(user_tags_suggest.getValue().length==0) {
		$('#user-tags').addClass('invalid');
		return false;
	}
	user.tags = user_tags_suggest.getValue();
	save_user_object();

	return true;
}

var user;

var avatar_added = false;
var location_added = false;
var user_tags_suggest = null;

function getOrientation(file, callback) {
  var reader = new FileReader();
 
  reader.onload = function(event) {
    var view = new DataView(event.target.result);
 
    if (view.getUint16(0, false) != 0xFFD8) return callback(-2);
 
    var length = view.byteLength,
        offset = 2;
 
    while (offset < length) {
      var marker = view.getUint16(offset, false);
      offset += 2;
 
      if (marker == 0xFFE1) {
        if (view.getUint32(offset += 2, false) != 0x45786966) {
          return callback(-1);
        }
        var little = view.getUint16(offset += 6, false) == 0x4949;
        offset += view.getUint32(offset + 4, little);
        var tags = view.getUint16(offset, little);
        offset += 2;
 
        for (var i = 0; i < tags; i++)
          if (view.getUint16(offset + (i * 12), little) == 0x0112)
            return callback(view.getUint16(offset + (i * 12) + 8, little));
      }
      else if ((marker & 0xFF00) != 0xFF00) break;
      else offset += view.getUint16(offset, false);
    }
    return callback(-1);
  };
 
  reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
};

$(function(){	
	$('#upload-profile-image').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		srcOrientation = 6
		getOrientation(file, function(orientation) {
		    srcOrientation = orientation;
		});

		$("#upload-profile-image-spinner").show();
		reader.onload = function(e) {
			var img = document.createElement("img");
        	img.src = reader.result;
        	
        	img.onload = function() {

				var canvas = document.createElement("canvas");
		        var ctx = canvas.getContext("2d");
		        ctx.drawImage(img, 0, 0);
		 
		        var MAX_WIDTH   = 400;
		        var MAX_HEIGHT  = 400;
		        var width       = img.width;
		        var height      = img.height;
		 
		        var tmp_ratio_width = width/MAX_WIDTH;
		        var tmp_ratio_height = height/MAX_HEIGHT;
		 
		        var tmp_ratio = tmp_ratio_width;
		        if(tmp_ratio_width<tmp_ratio_height)
		            tmp_ratio = tmp_ratio_height;
		           
		        if(tmp_ratio>1) {
		            width=width/tmp_ratio;
		            height=height/tmp_ratio;
		        }
		 
		        canvas.width = width;
		        canvas.height = height;
		        var ctx = canvas.getContext("2d");
		        switch (srcOrientation) {
		          case 2: ctx.transform(-1, 0, 0, 1, width, 0); break;
		          case 3: ctx.transform(-1, 0, 0, -1, width, height ); break;
		          case 4: ctx.transform(1, 0, 0, -1, 0, height ); break;
		          case 5: ctx.transform(0, 1, 1, 0, 0, 0); break;
		          case 6:
		          canvas.width=height;
		          canvas.height=width;
		          ctx = canvas.getContext("2d");
		          ctx.transform(0, 1, -1, 0, height, 0);
		          break;
		          case 7: ctx.transform(0, -1, -1, 0, height , width); break;
		          case 8: ctx.transform(0, -1, 1, 0, 0, width); break;
		          default: ctx.transform(1, 0, 0, 1, 0, 0);
		        }

		    	ctx.drawImage(img, 0, 0, width, height);

		    	var dataurl = canvas.toDataURL("image/png");	
		    	upload_image(dataurl, $("#email").val(), "uploaded-avatar");
        		jQuery.each($('.form-img-1 img'), function(i, e){
		        	user.avatar = dataurl;
					avatar_added = true;
					save_user_object();		
					e.src = dataurl;
					$('#uploaded-avatar').attr('src', dataurl);
				});
        	}

		}

		if (file) {
			reader.readAsDataURL(file);
		}
	});
	
	jQuery('.btn-second-next').on( "click", function() {
		if(!validate_first_step())
			return false;

		update_profile_image();

        jQuery('#fs_first_step').removeClass('show-data');
		jQuery('#fs_first_step').addClass('hide-data');        
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('show-data');
    });
	
	jQuery('.btn-third-next').on( "click", function() {
		if(!validate_second_step())
			return false;

		update_profile_image();

        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        jQuery('#fs_fourth_step').removeClass('hide-data');
        jQuery('#fs_fourth_step').addClass('show-data');
		$('#the-user').val(JSON.stringify(user));

    });
	
	$('.product-image-upload').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		var id = $(this).data('id');
		
		reader.addEventListener("load", function () {
			$('#product-image-'+id).attr('src', reader.result);
		}, false);

		if (file) {
			reader.readAsDataURL(file);
		}
	});


	
	load_user();
});

function update_profile_image() {
	jQuery.each($('.form-img-1 img'), function(i, e){
		e.src = user.avatar;
	});
}

function save_user_object() {
	window.localStorage.setItem('user_buyer_' + $("#email").val(), JSON.stringify(user));
}

function get_user_object() {
	return JSON.parse(window.localStorage.getItem('user_buyer_' + $("#email").val()));
}

function clear_user_object() {
	window.localStorage.removeItem("user_buyer");
}

function load_user() {
	user = get_user_object();

	if(user == null)
		user = init_user();
	
	if(user.avatar!="") {
		jQuery.each($('#uploaded-avatar'), function(i, e){
				e.src = user.avatar;
			});
		avatar_added = true;
	}
	
	if(user.company_name!="") {
		$('#company-name').val(user.company_name);
	}
	
	if(user.user_location!={}) {
		$('#user-location').val(user.user_location.formatted_address);
		location_added = true;
	}

	if(user.tags!=[]) {
		if (user_tags_suggest != null)
			user_tags_suggest.setValue(user.tags);
	}
}

function init_user() {
	return {
		avatar: "",
		company_name: "",
		user_location: {},
		tags: [],
		type: "buyer"
	};
}

function upload_image(data, email, id)
{	
	$.ajax({
		type: "POST",
		url: api_host + "/api/onboard/upload_image",
		data:{image:data, email:email},
	})
	.done(function(response){
		$("#"+id).attr("src", response.image);
		user.avatar = response.image;
		avatar_added = true;
		save_user_object();	
		$("#upload-profile-image-spinner").hide();	
	})
	.fail(function(error){
		console.log(error)
	});
}