
	
// create the back to top button
//jQuery('body').prepend('<a href="javascript:void(0)" class="fs-back-to-top"> <i class="fa fa-angle-top"></i></a>');

var amountScrolled = 300;
jQuery(document).ready(function(){
	jQuery(window).scroll(function() {
		if ( jQuery(window).scrollTop() > amountScrolled ) {
			jQuery('a.fs-back-to-top').fadeIn('slow');
		} else {
			jQuery('a.fs-back-to-top').fadeOut('slow');
		}
	});
	jQuery('a.fs-back-to-top').click(function() {
		jQuery('html, body').animate({
			scrollTop: 0
		}, 2000);
		return false;
	});
});
		
	
function signupSeller() {
	if(!$('#email').val())
		return false;
	
	window.location = '/onboarding-seller?email='+$('#email').val()+'&firstname='+$('#firstname').val()+'&lastname='+$('#lastname').val()+'&companyname='+$('#companyname').val();
}	

/* scroll top bottom arrow */
jQuery(document).ready(function(){
	jQuery('a.sign-up-top').on('click',function (e) {
		jQuery('html, body').stop().animate({
			'scrollTop': jQuery($(this).attr('rel')).offset().top - 30
		}, 2000, 'swing', function () {});
	});
});



jQuery(document).ready(function () { 
	jQuery('.btn-first-back').on( "click", function() {
		jQuery('#fs_first_step').addClass('show-data');
        jQuery('#fs_first_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        
    });
	
	
	
	jQuery('.btn-second-back').on( "click", function() {
		jQuery('#fs_second_step').addClass('show-data');
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_third_step').addClass('hide-data');
        jQuery('#fs_third_step').removeClass('show-data');
		
        
    });	
});	

function validate_first_step() {
	var ret = true;
	var company_name = $('#company-name');
	var company_description = $('#company-description');
	var farm_location = $('#farm-location');
	
	company_name.removeClass('invalid');
	company_description.removeClass('invalid');
	$('.btn-img').removeClass('invalid');
	farm_location.removeClass('invalid');
	
	if(!company_name.val()) {
		company_name.addClass('invalid');
		ret = false;
	}
	if(!company_description.val()) {
		company_description.addClass('invalid');
		ret = false;
	}
	if(!avatar_added) {
		$('.btn-img').addClass('invalid');
		ret = false;
	}
	if(!location_added) {
		farm_location.addClass('invalid');
		ret = false;
	}
	
	if(ret) {
		user.company_name = company_name.val();
		user.company_description = company_description.val();
	}
	save_user_object();
	return ret;
}

function validate_second_step() {
	$('#user-locations').removeClass('invalid');

	if($('#my-saved-locations').html()=="") {
		$('#user-locations').addClass('invalid');
		return false;
	}
	save_user_object();

	return true;
}

function validate_third_step() {
	if($('#saved-products').html()=='') {
		alert('Please add at least one product');
		return false;
	}
	save_user_object();
	return true;
}

var user;

var avatar_added = false;
var location_added = false;
var product_tags_suggest = null;

$(function(){	
	$('#upload-profile-image').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		
		reader.addEventListener("load", function () {
			jQuery.each($('.form-img-1 img'), function(i, e){
				e.src = reader.result;
			});
			//$('#avatar-preview').attr('src', reader.result);
			user.avatar = reader.result;
			avatar_added = true;
			save_user_object();
		}, false);

		if (file) {
			reader.readAsDataURL(file);
		}
	});
	
	jQuery('.btn-second-next').on( "click", function() {
		if(!validate_first_step())
			return false;
        jQuery('#fs_first_step').removeClass('show-data');
		jQuery('#fs_first_step').addClass('hide-data');        
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('show-data');
    });
	
	jQuery('.btn-third-next').on( "click", function() {
		if(!validate_second_step())
			return false;
        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        jQuery('#fs_third_step').removeClass('hide-data');
        jQuery('#fs_third_step').addClass('show-data');
    });
	
	jQuery('.btn-form-done').on( "click", function() {
		if(!validate_third_step())
			return false;
		jQuery('#fs_third_step').addClass('hide-data');
        jQuery('#fs_third_step').removeClass('show-data');
        jQuery('#fs_fourth_step').removeClass('hide-data');
        jQuery('#fs_fourth_step').addClass('show-data');
		$('#the-user').html(JSON.stringify(user));
        console.log(user);
    });

	
	$('#add-user-location').click(function() {
		var id = new Date().getTime();
		var place = autocomplete2.getPlace();
		if(typeof place == 'undefined')
			return false;
		$('#my-locations').append('<div class="col-md-12" style="background-color:#eee;" id="user-address-'+id+'"><div class="col-md-5">Location</div><div class="col-md-7 address-name" style="border: 1px dotted grey;">'+place.formatted_address+'</div><div class="col-md-5">Hours</div><div class="col-md-7">    <select class="select-day"><option>Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option></select>:    <select class="select-from"><option>00 AM</option><option>01 AM</option><option>02 AM</option><option>03 AM</option><option>04 AM</option><option>05 AM</option><option>06 AM</option><option>07 AM</option><option>08 AM</option><option>09 AM</option><option>10 AM</option><option>11 AM</option><option>12 PM</option><option>01 PM</option><option>02 PM</option><option>03 PM</option><option>04 PM</option><option>05 PM</option><option>06 PM</option><option>07 PM</option><option>08 PM</option><option>09 PM</option><option>10 PM</option><option>11 PM</option></select>-<select class="select-to"><option>00 AM</option><option>01 AM</option><option>02 AM</option><option>03 AM</option><option>04 AM</option><option>05 AM</option><option>06 AM</option><option>07 AM</option><option>08 AM</option><option>09 AM</option><option>10 AM</option><option>11 AM</option><option>12 PM</option><option>01 PM</option><option>02 PM</option><option>03 PM</option><option>04 PM</option><option>05 PM</option><option>06 PM</option><option>07 PM</option><option>08 PM</option><option>09 PM</option><option>10 PM</option><option>11 PM</option></select></div><a href="#" onclick="addTimesToLocation()" id="add_times">+</a><div class="col-md-4 col-md-offset-4"><a href="#" class="btn btn-success pull-left" onclick="saveLocation('+id+')">Save</a><a href="#" class="btn btn-default pull-right" onclick="removeAddress('+id+')">Remove</a></div></div>');
	});
	
	$('.product-image-upload').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		var id = $(this).data('id');
		
		reader.addEventListener("load", function () {
			$('#product-image-'+id).attr('src', reader.result);
		}, false);

		if (file) {
			reader.readAsDataURL(file);
		}
	});

	product_tags_suggest = $('#product-tags').magicSuggest({
		allowFreeEntries: false,
		data: ['Apple', 'Apricot', 'Avocado', 'Banana', 'Bilberry', 'Blackberry', 'Blackcurrant', 'Blueberry', 'Boysenberry', 'Currant', 'Cherry', 'Cherimoya', 'Cloudberry', 'Coconut', 'Cranberry', 'Cucumber', 'Custard apple', 'Damson', 'Date', 'Dragonfruit', 'Durian']
    });
	
	load_user();
});

function removeAddress(id) {
	$('#user-address-'+id).remove();
}

function saveLocation(id) {
	$('#my-saved-locations').append('<div class="col-md-12" style="background-color:#eee;">'+$('#user-address-'+id+' .address-name').html()+' '+$('#user-address-'+id+' .select-day option:selected').html()+' '+$('#user-address-'+id+' .select-from option:selected').html()+' '+$('#user-address-'+id+' .select-to option:selected').html()+'</div>');
	$('#user-address-'+id).remove();
}

function removeProduct() {
	clearProductForm();
}

function clearProductForm() {
	$('#product-name').val('');
	$('#product-description').val('');
	$('#product-image-1').attr('src', 'landingpage-images/upload-icon.png');
	$('#product-image-2').attr('src', 'landingpage-images/upload-icon.png');
	$('#product-image-3').attr('src', 'landingpage-images/upload-icon.png');
}

function saveProduct() {
	$('#product-name').removeClass('invalid');
	$('#product-description').removeClass('invalid');
	$('#product-image-1').removeClass('invalid');
	
	var product = {};
	product.name = $('#product-name').val();
	product.description = $('#product-description').val();
	product.images = [];
	if($('#product-image-1').attr('src')!='landingpage-images/upload-icon.png')
		product.images.push($('#product-image-1').attr('src'));
	if($('#product-image-2').attr('src')!='landingpage-images/upload-icon.png')
		product.images.push($('#product-image-1').attr('src'));
	if($('#product-image-3').attr('src')!='landingpage-images/upload-icon.png')
		product.images.push($('#product-image-1').attr('src'));
	product.tags = product_tags_suggest.getValue();
	
	if(!product.name)
		$('#product-name').addClass('invalid');
	if(!product.description)
		$('#product-description').addClass('invalid');
	if(typeof product.images[0] == 'undefined')
		$('#product-image-1').addClass('invalid');
	
	if(product.name && product.description && typeof product.images[0] !='undefined') {
		$('#saved-products').append('<div class="col-md-12" style="background-color:#eee;"><div class="col-md-3"><img src="'+product.images[0]+'"></div><div class="col-md-9">'+product.name+'</div></div>');
		clearProductForm();
		user.products.push(product);
	}
}

function init_user() {
	return {
		avatar: "",
		company_name: "",
		company_description: "",
		farm_location: {},
		user_locations: {},
		products: []
	};
}

function save_user_object() {
	window.localStorage.setItem('user_seller', JSON.stringify(user));
}

function get_user_object() {
	return JSON.parse(window.localStorage.getItem('user_seller'));
}

function load_user() {
	user = get_user_object();

	if(user == null)
		user = init_user();
	
	if(user.avatar!="") {
		jQuery.each($('.form-img-1 img'), function(i, e){
				e.src = user.avatar;
			});
		avatar_added = true;
	}
	
	if(user.company_name!="") {
		$('#company-name').val(user.company_name);
	}
	
	if(user.company_description!="") {
		$('#company-description').val(user.company_description);
	}

	if(user.farm_location!={}) {
		$('#farm-location').val(user.farm_location.formatted_address);
		location_added = true;
	}
}

jQuery(document).ready(function () { 
 jQuery('.custom-toggle-link').on( "click", function() {
  var panid = jQuery(this).attr('href');
  jQuery('.custom-toggle-link').each(function(){
   if(jQuery(this).attr('href')!=panid)
   {
    jQuery(this).removeClass('toggle-open');
   }
   });
  
  if(jQuery(this).hasClass('toggle-open')){jQuery(this).removeClass('toggle-open');}else{
   jQuery(this).addClass('toggle-open');
  }
    });
 
});