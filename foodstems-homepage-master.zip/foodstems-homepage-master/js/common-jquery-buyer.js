
	
// create the back to top button
//jQuery('body').prepend('<a href="javascript:void(0)" class="fs-back-to-top"> <i class="fa fa-angle-top"></i></a>');

var amountScrolled = 300;
jQuery(document).ready(function(){
	jQuery(window).scroll(function() {
		if ( jQuery(window).scrollTop() > amountScrolled ) {
			jQuery('a.fs-back-to-top').fadeIn('slow');
		} else {
			jQuery('a.fs-back-to-top').fadeOut('slow');
		}
	});
	jQuery('a.fs-back-to-top').click(function() {
		jQuery('html, body').animate({
			scrollTop: 0
		}, 2000);
		return false;
	});
});

function onboardBuyer1() {
	if(!$('#email1').val())
		return false;

	window.location='/onboarding-buyer?email='+$('#email1').val();
}

function onboardBuyer2() {
	if(!$('#email2').val())
		return false;

	window.location='/onboarding-buyer?email='+$('#email2').val();
}

/* scroll top bottom arrow */
jQuery(document).ready(function(){
	jQuery('a.sign-up-top').on('click',function (e) {
		jQuery('html, body').stop().animate({
			'scrollTop': 100//jQuery($(this).attr('rel')).offset().top - 30
		}, 2000, 'swing', function () {});
	});
});



jQuery(document).ready(function () { 
	jQuery('.btn-first-back').on( "click", function() {
		jQuery('#fs_first_step').addClass('show-data');
        jQuery('#fs_first_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        
    });
	
	
	
	jQuery('.btn-second-back').on( "click", function() {
		jQuery('#fs_second_step').addClass('show-data');
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_third_step').addClass('hide-data');
        jQuery('#fs_third_step').removeClass('show-data');
		
        
    });	
});	

function validate_first_step() {
	var ret = true;
	var company_name = $('#company-name');
	var user_location = $('#user-location');
	
	company_name.removeClass('invalid');
	$('.btn-img').removeClass('invalid');
	user_location.removeClass('invalid');
	
	if(!company_name.val()) {
		company_name.addClass('invalid');
		ret = false;
	}
	if(!avatar_added) {
		$('.btn-img').addClass('invalid');
		ret = false;
	}
	if(!location_added) {
		user_location.addClass('invalid');
		ret = false;
	}
	
	if(ret) {
		user.company_name = company_name.val();
	}
	save_user_object();

	return ret;
}

function validate_second_step() {
	$('#user-tags').removeClass('invalid');
	if(user_tags_suggest.getValue().length==0) {
		$('#user-tags').addClass('invalid');
		return false;
	}
	user.tags = user_tags_suggest.getValue();
	save_user_object();

	return true;
}

var user;

var avatar_added = false;
var location_added = false;
var user_tags_suggest = null;

$(function(){	
	$('#upload-profile-image').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		
		reader.addEventListener("load", function () {
			jQuery.each($('.form-img-1 img'), function(i, e){
				e.src = reader.result;
			});
			//$('#avatar-preview').attr('src', reader.result);
			user.avatar = reader.result;
			avatar_added = true;
			save_user_object();
		}, false);

		if (file) {
			reader.readAsDataURL(file);
		}
	});
	
	jQuery('.btn-second-next').on( "click", function() {
		if(!validate_first_step())
			return false;
        jQuery('#fs_first_step').removeClass('show-data');
		jQuery('#fs_first_step').addClass('hide-data');        
        jQuery('#fs_second_step').removeClass('hide-data');
        jQuery('#fs_second_step').addClass('show-data');
    });
	
	jQuery('.btn-third-next').on( "click", function() {
		if(!validate_second_step())
			return false;
        jQuery('#fs_second_step').addClass('hide-data');
        jQuery('#fs_second_step').removeClass('show-data');
        jQuery('#fs_fourth_step').removeClass('hide-data');
        jQuery('#fs_fourth_step').addClass('show-data');
		$('#the-user').html(JSON.stringify(user));
        console.log(user);
    });
	
	$('.product-image-upload').change(function(){
		var file = $(this)[0].files[0];
		var reader = new FileReader();
		var id = $(this).data('id');
		
		reader.addEventListener("load", function () {
			$('#product-image-'+id).attr('src', reader.result);
		}, false);

		if (file) {
			reader.readAsDataURL(file);
		}
	});

	user_tags_suggest = $('#user-tags').magicSuggest({
		allowFreeEntries: false,
		data: ['Apple', 'Apricot', 'Avocado', 'Banana', 'Bilberry', 'Blackberry', 'Blackcurrant', 'Blueberry', 'Boysenberry', 'Currant', 'Cherry', 'Cherimoya', 'Cloudberry', 'Coconut', 'Cranberry', 'Cucumber', 'Custard apple', 'Damson', 'Date', 'Dragonfruit', 'Durian'],
		selectionPosition: 'bottom',
        selectionStacked: true,
        selectionRenderer: function(data){
            return data.name;
        }
    });
	
	load_user();
});

function save_user_object() {
	window.localStorage.setItem('user_buyer', JSON.stringify(user));
}

function get_user_object() {
	return JSON.parse(window.localStorage.getItem('user_buyer'));
}

function load_user() {
	user = get_user_object();

	if(user == null)
		user = init_user();
	
	if(user.avatar!="") {
		jQuery.each($('.form-img-1 img'), function(i, e){
				e.src = user.avatar;
			});
		avatar_added = true;
	}
	
	if(user.company_name!="") {
		$('#company-name').val(user.company_name);
	}
	
	if(user.user_location!={}) {
		$('#user-location').val(user.user_location.formatted_address);
		location_added = true;
	}
	
	if(user.tags!=[]) {
		user_tags_suggest.setValue(user.tags);
	}
}

function init_user() {
	return {
		avatar: "",
		company_name: "",
		user_location: {},
		tags: []
	};
}
