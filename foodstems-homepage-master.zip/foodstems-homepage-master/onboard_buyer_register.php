
<!doctype html>
<html lang="en" class="">
<head>
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<![endif]-->
	
	<meta charset="utf-8">
	<title>Food Stems | Sign Up Form</title>
	<meta name="description" content="Foodstems">
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="" content="">
	<link rel="stylesheet" href="/assets/onboard/css/style.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/shortcode.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/responsive.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/bootstrap/bootstrap.min.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/reset.min.css" type="text/css" media="all">
	
	<link rel="stylesheet" href="/assets/onboard/css/font-awesome/css/font-awesome.min.css" type="text/css" media="all">
	<script type="text/javascript" src="/config.js"></script>
	<script src="/assets/onboard/js/jquery-2.1.4.min.js" type="text/javascript"></script> 
	<script src="/assets/onboard/js/common-jquery-buyer.js?<?php echo time(); ?>" type="text/javascript" ></script>
	<script src="/assets/onboard/js/bootstrap.min.js" type="text/javascript" ></script>
	
	<link href="/assets/onboard/plugins/magicsuggest/magicsuggest-min.css" rel="stylesheet">
	<script src="/assets/onboard/plugins/magicsuggest/magicsuggest-min.js"></script>
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<![endif]-->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet"> 
	<style>
	.invalid {
		border: 2px solid red !important;
	}
	pre {
    white-space: pre-wrap;       /* Since CSS 2.1 */
    white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */
    white-space: -pre-wrap;      /* Opera 4-6 */
    white-space: -o-pre-wrap;    /* Opera 7 */
    word-wrap: break-word;       /* Internet Explorer 5.5+ */
}
	</style>
</head>
<body>
<div id="fs-top" class="fs-wrapper fs-form-bg">
	<div class="home-top-banner">
		<div class="header-container">
			<header class="header clearfix">
				
				<nav role="navigation" class="navbar navbar-default" id="main-menu"> <!-- navbar-fixed-top -->
					<div class="container">
						<div class="navbar-header">
							<a href="/" class="navbar-brand pull-left"><img class="img-logo" src="/assets/onboard/images/fslogo-main.png" /></a>
						</div>
					</div> 
				</nav>
			</header>	
		</div>
	</div>	
	<main id="fs-forms">
		<section class="main-content">
			<div class="form-common-main">
			<form role="form" class="boxshadow visible" id="fs_first_step" method="post" action="javascript:void(0)">
				
				<div class="fs-first-step form-inner visible" >
					<div class="form-left-side">
						<h1>Set up your profile.</h1>
						<p>Enter the name of your business and location. Upload your profile picture.</p>
						<!--
						<div class="form-img-1 fs-center avatar-wrapper">
							<img src="http://via.placeholder.com/200x250" id="avatar-preview" />
						</div>
						-->
					</div>
					<div class="form-right-side">
						<div class="fs-forms-steps-main fs-center">
							<ul id="fs_form_steps">
								<li id="first" class="fs_active"></li>
								<li></li>
							</ul>
						</div>
						<div class="form-inputs-all">
							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np"><i class="fa fa-building"></i></label>
								<div class="col-xs-12 np">
									 <input type="text" class="form-control" id="company-name" name="" placeholder="Company Name" />
								</div>
							</div>
							
							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np"><i class="fa fa-map-marker"></i></label>
								<div class="col-xs-12 np">
									 <input type="text" class="form-control " id="user-location" name="" placeholder="Your Location"/>
								</div>
							</div>
							
<div class="form-group">
							<div class="col-md-3 col-sm-4 col-xs-12 np" style="margin:20px;">
								<div class="upload-btn-wrapper">
									<button class="btn-img">
										<img src="/assets/onboard/images/spinner.gif" id="upload-profile-image-spinner" style="position:absolute;opacity:0.5; display: none; height: 60px;">
										<img src="/assets/onboard/images/upload-icon.png" style="width:200px;"/ id="uploaded-avatar"></button>
									<input class="fs-upload-images" type="file" name="" id="upload-profile-image"/>
								</div>
							</div>
							<div class="col-md-8 col-sm-8 col-xs-12 np"><p class="text-btn-upload">Upload an image</p></div>
						</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-right btn-second-next" >Next <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
				
			</form>	
			
			<form role="form" class="hide-data visible" id="fs_second_step" method="post" action="javascript:void(0)">
				<div class="fs-second-step form-inner visible" >
					<div class="form-left-side">
						<h1>Set up your preferences.</h1>
						<p>Enter the products you are looking for.</p>
						<div class="form-img-1 fs-center">
							<img src="http://via.placeholder.com/200x250"/>
						</div>
					</div>
					<div class="form-right-side">
						<div class="fs-forms-steps-main fs-center">
							<ul id="fs_form_steps">
								<li id="first"></li>
								<li class="fs_active"></li>
							</ul>
						</div>
						
						<div class="form-group add-location form-inputs-all">
							<input type="text" class="form-control input-address" id="user-tags" name="" placeholder="Search for product tags"/>
							<!--<a href="javascript:void(0)" class="btn btn-success add-location-btn" id="add-user-location">Add</a>-->
						</div>
						
						<div class="form-locations-all height-common">
							
							
						</div>
						<div class="row">
							<div class="col-xs-12">
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-left btn-first-back" ><i class="fa fa-long-arrow-left"></i> Previous</a>
								
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-right btn-third-next" >Next <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</form>	

			<form role="form" class="hide-data visible" id="fs_fourth_step" >
				<input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']); ?>" id="email"/>
				<div class="fs-fourth-step form-inner visible" >
					<div class="form-left-side">
						<div class="fs-center">
							<img class="img-responsive fs-left-img" src="/assets/onboard/images/featured-3-img.png" />
						</div>
					</div>
					<div class="form-right-side" id="succes-div">
						<h1>Your profile is ready!</h1>
						<p>A temporary password has been sent to your email address <?php echo htmlspecialchars($_GET['email']); ?>. Please wait a moment while we direct you to the platform.</p>
						
						<div class="row" id="register-buyer-row">
							<div class="col-xs-12 fs-center ">
								<a href="javascript:void(0)" onclick="register_buyer()" id="register_btn" class="btn btn-primary btn-form-custom btn-form-thanks">Ok, got it!</a>
								<input type="hidden" id="the-user" name="the_user" />
							</div>
						</div>
						<div class="row" id="loading-button-buyer" style="display: none">
							<div class="col-xs-12 fs-center ">
								<img src="/assets/onboard/images/loading.gif" style="height: 100px">	
							</div>
						</div>	

									
					</div>
					<div class="form-right-side" id="error-div" style="display: none">
						<h1>Error!</h1>
						<p>Email already registered. Please go back and use another email</p>
						<a href="/" class="btn btn-primary btn-form-custom pull-left" >Back </a>
					</div>


							
						
				</div>
			</form>	
			
			</div>
			
				
		</section>
	
	</main>	
</div>
<script>

	var items = []; 
	$('.ms-sel-item').each(function(k,v) { items.push(($(v).text())) });
	var exclude = items.join(",");
	
    $.get(Foodstems.api_host + '/api/tags?exclude='+exclude, function(data){
        user_tags_suggest = $('#user-tags').magicSuggest({
            allowFreeEntries: false,
            valueField: 'id',
            displayField: 'name',
            selectionPosition: 'bottom',
            selectionStacked: true,
            selectionRenderer: function(data){
                return data.name;
            },
            data: data.data
        });
    });

      function submit_form() {
      	jQuery("#fs_fourth_step").submit();
      }
      var placeSearch, autocomplete, autocomplete2;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('user-location')),
            {types: ['address'], componentRestrictions: { country: 'usa' }});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
		}

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();
		user.user_location = place;
		location_added = true;
      }
	  
      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
	  
	  function geolocate2() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete2.setBounds(circle.getBounds());
          });
        }
      }
    </script>
<script src="https://maps.googleapis.com/maps/api/js?libraries=places&amp;key=AIzaSyD3fjBxGZs978019IGh6vddwux79RocB7Q&callback=initAutocomplete" async defer></script>
</body>
</html>
