
<!doctype html>
<html lang="en" class="">
<head>
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<![endif]-->
	
	<meta charset="utf-8">
	<title>Food Stems | Sign Up Form</title>
	<meta name="description" content="Foodstems">
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="" content="">
	<link rel="stylesheet" href="/assets/onboard/css/style.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/shortcode.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/responsive.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/bootstrap/bootstrap.min.css" type="text/css" media="all">
	<link rel="stylesheet" href="/assets/onboard/css/reset.min.css" type="text/css" media="all">
	
	<link rel="stylesheet" href="/assets/onboard/css/font-awesome/css/font-awesome.min.css" type="text/css" media="all">
	
	<script type="text/javascript" src="/config.js"></script>
	<script src="/assets/onboard/js/jquery-2.1.4.min.js" type="text/javascript"></script> 
	<script src="/assets/onboard/js/common-jquery.js?<?php echo time(); ?>" type="text/javascript" ></script>
	<script src="/assets/onboard/js/bootstrap.min.js" type="text/javascript" ></script>
		
	<link href="/assets/onboard/plugins/magicsuggest/magicsuggest-min.css" rel="stylesheet">
	<script src="/assets/onboard/plugins/magicsuggest/magicsuggest-min.js"></script>

	
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<![endif]-->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet"> 
	<style>
	.invalid {
		border: 2px solid red !important;
	}
	pre {
    white-space: pre-wrap;       /* Since CSS 2.1 */
    white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */
    white-space: -pre-wrap;      /* Opera 4-6 */
    white-space: -o-pre-wrap;    /* Opera 7 */
    word-wrap: break-word;       /* Internet Explorer 5.5+ */
}
	</style>
</head>
<body>
<div id="fs-top" class="fs-wrapper fs-form-bg">
	<div class="home-top-banner">
		<div class="header-container">
			<header class="header clearfix">
				
				<nav role="navigation" class="navbar navbar-default" id="main-menu"> <!-- navbar-fixed-top -->
					<div class="container">
						<div class="navbar-header">
							<a href="/" class="navbar-brand pull-left"><img class="img-logo" src="/assets/onboard/images/fslogo-main.png" /></a>
						</div>
					</div> 
				</nav>
			</header>	
		</div>
	</div>	
	<main id="fs-forms">
		<input type="hidden" name="email" value="<?php print isset($_GET['email']) ? $_GET["email"] : "" ?>" id="email"/>
		<input type="hidden" name="first_name" value="<?php print isset($_GET['firstname']) ? $_GET["firstname"] : "" ?>" id="firstname"/>
		<input type="hidden" name="last_name" value="<?php print isset($_GET['lastname']) ? $_GET["lastname"] : "" ?>" id="lastname"/>
		<section class="main-content">
			<div class="form-common-main">
			<form role="form" class="boxshadow visible" id="fs_first_step" method="post" action="javascript:void(0)">
				<div class="fs-first-step form-inner visible" >
					<div class="form-left-side">
						<h1>Tell us about your company.</h1>
						<p>Upload your profile picture. Enter the name of your business along with a description and location.</p>
						<!--
						<div class="form-img-1 fs-center avatar-wrapper">
							<img src="https://via.placeholder.com/200x250" id="avatar-preview"/>							
						</div>
						-->
					</div>
					<div class="form-right-side">
						<div class="fs-forms-steps-main fs-center">
							<ul id="fs_form_steps">
								<li id="first" class="fs_active"></li>
								<li></li>
								<li></li>
							</ul>
						</div>
						
						<div class="form-group">
							<div class="col-md-3 col-sm-4 col-xs-12 np">
								<div class="upload-btn-wrapper">
									<button class="btn-img" id="avatar-btn-image">
										<img src="/assets/onboard/images/spinner.gif" id="upload-profile-image-spinner" style="position:absolute;opacity:0.5; display: none; height: 60px;">
										<img src="/assets/onboard/images/upload-icon.png" id="uploaded-avatar" />
									</button>
									<input class="fs-upload-images" type="file" name="" id="upload-profile-image"/>
									<!--<input id="upload-profile-image-resize" class="fs-upload-images" type="file" type="file" onchange="handleFiles()">-->
								</div>
							</div>
							<div class="col-md-9 col-sm-8 col-xs-12 np"><p class="text-btn-upload">Upload logo or profile image</p></div>
						</div>
						<div class="form-inputs-all height-common">
							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np"><i class="fa fa-building"></i></label>
								<div class="col-xs-12 np">
									 <input type="text" value="<?php print isset($_GET["companyname"]) ? $_GET["companyname"] : "" ?>" class="form-control" id="company-name" name="" placeholder="Company Name" value=""/>
								</div>
							</div>
							
							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np"><i class="fa fa-file-text"></i></label>
								<div class="col-xs-12 np">
									<textarea class="form-control" col="10" rows="5" id="company-description" name="" placeholder="Company Description"></textarea>
								</div>
							</div>
							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np"><i class="fa fa-map-marker"></i></label>
								<div class="col-xs-12 np">
									 <input type="text" class="form-control " id="farm-location" name="" placeholder="Farm Location"/>
								</div>
							</div>
							
						</div>
						<div class="row">
							<div class="col-xs-12">
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-right btn-second-next" >Next <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
				
			</form>	
			
			<form role="form" class="hide-data visible" id="fs_second_step" method="post" action="javascript:void(0)">
				<div class="fs-second-step form-inner visible" >
					<div class="form-left-side">
						<h1>Where do you sell at?</h1>
						<p>Choose which locations and days of the week you already sell at or plan to sell at.</p>
						<div class="form-img-1 fs-center">
							<img src="https://via.placeholder.com/200x250"/>
						</div>
					</div>
					<div class="form-right-side">
						<div class="fs-forms-steps-main fs-center">
							<ul id="fs_form_steps">
								<li id="first"></li>
								<li class="fs_active"></li>
								<li></li>
							</ul>
						</div>
						
						<script>
							var markets = {
								'1' : "Ferry Plaza Farmer's Market (Embarcadero)",
								'2' : "Heart of the City Farmers' Market (Civic Center)",
							}
	
						</script>

						<div class="form-group add-location form-inputs-all">
							<!--<input type="text" class="form-control input-address" id="market-locations" name="" placeholder="Input Address"/>-->
							<select name="markets" id="market_id" class="form-control input-address" onchange="get_market()">
							<option></option>
								<option value="1" >Ferry Plaza Farmer&#39;s Market (Embarcadero)</option>
								<option value="2" >Heart of the City Farmer&#39;s Market (Civic Center)</option>
								<option value="3" >Mission Bay/Spark Social</option>
								<option value="4" >Daly City Farmer&#39;s Market at Serramonte Center</option>
							</select>
							
							<!--<a href="javascript:void(0)" class="btn btn-success add-location-btn" id="add-user-location">Add</a>-->

								<span id="market_1_data" style="display: none">
									<table class="table table-responsive">
											<input type="hidden" name="added_market" class="added_market" value="1" />
											<tr>
												<td>Market</td>
												<td><span class="market_name_td">Ferry Plaza Farmer&#39;s Market (Embarcadero)</span></td>
											</tr>
											<tr>
												<td>Hours</td>
												<td>
														<input id="m_time_1" class="market_time" type="checkbox" name="market_time" value="1">
														<label id="label_m_time_1" for="m_time_1">
															Tuesday: 10am-2pm
														</label>
														<br/>
														<input id="m_time_2" class="market_time" type="checkbox" name="market_time" value="2">
														<label id="label_m_time_2" for="m_time_2">
															Thursday: 10am-2pm
														</label>
														<br/>
														<input id="m_time_3" class="market_time" type="checkbox" name="market_time" value="3">
														<label id="label_m_time_3" for="m_time_3">
															Saturday: 10am-2pm
														</label>
														<br/>
												</td>
											</tr>
											<tr>
											<td colspan="2">
												<div class="col-md-12 text-center">
														<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-save-btn" onclick="add_market()">Save</a>
														<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-remove-btn remove-market">Remove</a>
												</div>
											</td>
											</tr>																				
										</table>
								
								</span>
								<span id="market_2_data" style="display: none">
									<table class="table table-responsive">
											<input type="hidden" name="added_market" class="added_market" value="2" />
											<tr>
												<td>Market</td>
												<td><span class="market_name_td">Heart of the City Farmers&#39; Market (Civic Center)</span></td>
											</tr>
											<tr>
												<td>Hours</td>
												<td>
														<input id="m_time_4" class="market_time" type="checkbox" name="market_time" value="4">
														<label id="label_m_time_4" for="m_time_4">
															Wednesday: 7am-5:30pm
														</label>
														<br/>
														<input id="m_time_5" class="market_time" type="checkbox" name="market_time" value="5">
														<label id="label_m_time_5" for="m_time_5">
															Sunday: 7am-5:30pm
														</label>
														<br/>
												</td>
											</tr>
											<tr>
											<td colspan="2">
												<div class="col-md-12 text-center">
														<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-save-btn" onclick="add_market()">Save</a>
														<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-remove-btn remove-market">Remove</a>
												</div>
											</td>
											</tr>																				
										</table>
								
								</span>
								<span id="market_3_data" style="display: none">
									<table class="table table-responsive">
											<input type="hidden" name="added_market" class="added_market" value="3" />
											<tr>
												<td>Market</td>
												<td><span class="market_name_td">Mission Bay/Spark Social</span></td>
											</tr>
											<tr>
												<td>Hours</td>
												<td>
														<input id="m_time_6" class="market_time" type="checkbox" name="market_time" value="6">
														<label id="label_m_time_6" for="m_time_6">
															Monday: 10am:12pm
														</label>
														<br/>
														<input id="m_time_7" class="market_time" type="checkbox" name="market_time" value="7">
														<label id="label_m_time_7" for="m_time_7">
															Saturday: 10am:12pm
														</label>
														<br/>
												</td>
											</tr>
											<tr>
											<td colspan="2">
												<div class="col-md-12 text-center">
														<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-save-btn" onclick="add_market()">Save</a>
														<a href="javascript:void(0)" class="ml-15 btn btn-primary btn-form-custom location-remove-btn remove-market">Remove</a>
												</div>
											</td>
											</tr>																				
										</table>
								
								</span>		

								<span id="market_4_data" style="display: none">
									<table class="table table-responsive">
											<input type="hidden" name="added_market" class="added_market" value="4" />
											<tr>
												<td>Market</td>
												<td><span class="market_name_td">Daly City Farmer&#39;s Market at Serramonte Center</span></td>
											</tr>
											<tr>
												<td>Hours</td>
												<td>
														<input id="m_time_8" class="market_time" type="checkbox" name="market_time" value="8">
														<label id="label_m_time_8" for="m_time_8">
															Thursday: 9am:1pm
														</label>
														<br/>
														<input id="m_time_9" class="market_time" type="checkbox" name="market_time" value="9">
														<label id="label_m_time_9" for="m_time_9">
															Saturday: 9am:1pm
														</label>
														<br/>
												</td>
											</tr>
											<tr>
											<td colspan="2">
												<div class="col-md-12 text-center">
														<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-save-btn" onclick="add_market()">Save</a>
														<a href="javascript:void(0)" class="ml-15 btn btn-primary btn-form-custom location-remove-btn remove-market">Remove</a>
												</div>
											</td>
											</tr>																				
										</table>
								
								</span>															
						</div>
						<script>

						</script>
						<div style="display: none">

						</div>
						<div class="form-locations-all height-common">
							<h4>My Location(s)</h4>
							<input type="hidden" id="my-locations-added" value="0" />
							<div class="view-locations visible">
								<div class="view-locations-inner">
									<div class="ul-locations-list">
										<div id="my-saved-locations"></div>
									</div>
								</div>
							</div>
							<div class="add-location-input visible show-data" style="display:none;" id="my-locations-container">
								<div class="location-input-inner col-md-12">
									<div id="my-locations">
									</div>
								</div>
							</div>
							

							
						</div>
						<div class="row">
							<div class="col-xs-12">
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-left btn-first-back" ><i class="fa fa-long-arrow-left"></i> Previous</a>
								
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-right btn-third-next" >Next <i class="fa fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</form>	
			
			
			<form role="form" class="hide-data visible" id="fs_third_step" method="post" action="javascript:void(0)">
				<div class="fs-third-step form-inner visible" >
					<div class="form-left-side">
						<h1>Add your products.</h1>
						<p>Enter at least one product along with a description, photos, and the tags associated with that product.</p>
						<div class="form-img-1 fs-center">
							<img src="https://via.placeholder.com/200x250" />
						</div>
					</div>
					<div class="form-right-side">
						<div class="fs-forms-steps-main fs-center">
							<ul id="fs_form_steps">
								<li id="first"></li>
								<li></li>
								<li class="fs_active"></li>
							</ul>
						</div>
						
						<div class="form-locations-all">
							<h4>My Product(s)</h4>
							<div class="view-products visible show-data">
								<div class="view-products-inner">
									<div class="ul-products-list">
										<div id="saved-products"></div>
									</div>
								</div>
							</div>
						<div class="form-inputs-all res-label">
							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np col-md-3">Name</label>
								<div class="col-xs-12 np">
									 <input type="text" class="form-control" id="product-name" name="" placeholder="">
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np col-md-3">Description</label>
								<div class="col-xs-12 np">
                                    <textarea class="form-control" id="product-description" name="" placeholder=""></textarea>
								</div>
							</div>

							<div class="form-group">
								<label for="inputEmail" class="table-middle control-label col-xs-1 np col-md-3">Category</label>
								<div class="col-xs-12 np">
                                    <select name="category_id" id="category_id" class="table-middle control-label col-xs-1 np col-md-3 form-control">

                                    </select>
								</div>
							</div>

						<div class="form-group">
							<label for="inputEmail" class="table-middle control-label col-xs-1 np col-md-3">Image<small>*Note (Upload at least one image)</small></label>
							<div class="col-md-3 col-sm-4 col-xs-12 np">
								<div class="upload-btn-wrapper">
									<button class="btn-img">
										<img src="/assets/onboard/images/spinner.gif" id="product-image-spinner-1" style="position:absolute;opacity:0.5; display: none; height: 60px;">
										<img src="/assets/onboard/images/upload-icon.png" id="product-image-1">
									</button>
									<input class="fs-upload-images product-image-upload" type="file" name="" data-id="1">
								</div>
							</div>
							<div class="col-md-3 col-sm-4 col-xs-12 np">
								<div class="upload-btn-wrapper">
									<button class="btn-img">
										<img src="/assets/onboard/images/spinner.gif" id="product-image-spinner-2" style="position:absolute;opacity:0.5; display: none; height: 60px;">
										<img src="/assets/onboard/images/upload-icon.png" id="product-image-2">
									</button>
									<input class="fs-upload-images product-image-upload" type="file" name="" data-id="2">
								</div>
							</div><div class="col-md-3 col-sm-4 col-xs-12 np">
								<div class="upload-btn-wrapper">
									<button class="btn-img">
										<img src="/assets/onboard/images/spinner.gif" id="product-image-spinner-3" style="position:absolute;opacity:0.5; display: none; height: 60px;">
										<img src="/assets/onboard/images/upload-icon.png" id="product-image-3">
									</button>
									<input class="fs-upload-images product-image-upload" type="file" name="" data-id="3">
								</div>
							</div>

							
						</div>

						<div class="form-group add-location form-inputs-all">
							<label for="inputEmail" class="table-middle control-label col-xs-1 np col-md-3">Tag <i class="fa fa-info-circle fa-1" title="Tags allow us to match buyers and sellers based on which products sellers are selling and which products buyers are looking for. For example if you sell Granny Smith Apples, you would enter the tags Apples and Granny Smith." data-toggle="tag-tooltip" style="font-size:14px !important;cursor: pointer;"></i></label>
							<div class="col-xs-12 np">
								<input type="text" class="form-control input-address" id="product-tags" name="" placeholder="Search for product tags" />
							</div>
							<!--<a href="javascript:void(0)" class="btn btn-success add-location-btn">Add</a>-->
						</div>
							<script>
							$(document).ready(function(){
							    $('[data-toggle="tag-tooltip"]').tooltip();   
							});
							</script>
							<div class="form-group">
								<div class="col-md-3 text-center">&nbsp;</div>

								<div class="col-md-9 text-center">							
												<a href="javascript:void(0)" class="btn btn-primary btn-form-custom products-save-btn" onclick="saveProduct()">Add</a>
												<!--
												<a href="javascript:void(0)" class="btn btn-primary btn-form-custom location-remove-btn" onclick="removeProduct()">Remove</a>   
												--> 
								</div>
							</div>
							
						</div>
							


						</div>
						<div class="row">
							<div class="col-xs-12">
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom pull-left btn-second-back" ><i class="fa fa-long-arrow-left"></i> Previous</a>
								
								<a href="javascript:void(0)" class="btn btn-primary btn-form-custom btn-form-done pull-right btn-packages-next disabled" id="products-done-button">Continue</a>
							</div>
						</div>
					</div>
				</div>
			</form>	
			
			<form role="form" class="hide-data visible" id="fs_fourth_step" >
				<div class="fs-fourth-step form-inner visible" >
					<div class="form-left-side">
						<div class="fs-center">
							<img class="img-responsive fs-left-img" src="/assets/onboard/images/featured-3-img.png" />
						</div>
					</div>
					<div class="form-right-side" id="succes-div">
						<h1>Your profile is ready!</h1>
						<p>A temporary password has been sent to your email address <?php echo htmlspecialchars($_GET['email']); ?>. Please wait a moment while we direct you to the platform.</p>
						<div class="row" id="register-seller-row">
							<div class="col-xs-12 fs-center ">
							
								<a href="javascript:void(0)" onclick="register_seller()" id="register_seller_btn" class="btn btn-primary btn-form-custom btn-form-thanks btn-register-seller">Ok, got it!</a>
								<input type="hidden" name="the_user" id="the-user" />
							</div>
						</div>
						<div class="row" id="loading-button-seller" style="display: none">
							<div class="col-xs-12 fs-center ">
								<img src="/assets/onboard/images/loading.gif" style="height: 100px">	
							</div>
						</div>						
					</div>
					<div class="form-right-side" id="error-div" style="display: none">
						<h1>Error!</h1>
						<p>Email already registered. Please go back and use another email</p>
						<a href="/" class="btn btn-primary btn-form-custom pull-left" >Back </a>
					</div>					
				</div>
			</form>	
			
			</div>
			
				
		</section>
	
	</main>	
</div>
<script>
	
	var items = []; 
	$('.ms-sel-item').each(function(k,v) { items.push(($(v).text())) });
	var exclude = items.join(",");

    $.get('https://dev.foodstems.com/v2/api/tags?exclude='+exclude, function(data){
 	   	product_tags_suggest = $('#product-tags').magicSuggest({
		allowFreeEntries: false,
		valueField: 'id',
        displayField: 'name',
        selectionPosition: 'bottom',
        selectionStacked: true,
        selectionRenderer: function(data){
            return data.name;
        },
		data: data.data
    	});
 	   });



      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete, autocomplete2;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('farm-location')),
            {types: ['address'], componentRestrictions: { country: 'usa' }});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);


        /*autocomplete2 = new google.maps.places.Autocomplete(
            (document.getElementById('user-locations')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete2.addListener('place_changed', fillInAddress2);*/
		}

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();
		user.farm_location = place;
		location_added = true;
      }
	  
	  /*function fillInAddress2() {
        // Get the place details from the autocomplete object.
        var place = autocomplete2.getPlace();
		console.log(place);
      }*/

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
	  
	  /*function geolocate2() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete2.setBounds(circle.getBounds());
          });
        }
      }*/
    </script>
<script src="//maps.googleapis.com/maps/api/js?libraries=places&amp;key=AIzaSyD3fjBxGZs978019IGh6vddwux79RocB7Q&callback=initAutocomplete" async defer></script>
</body>
</html>
